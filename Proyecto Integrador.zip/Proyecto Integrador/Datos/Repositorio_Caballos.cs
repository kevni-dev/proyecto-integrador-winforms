﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace Proyecto_Integrador.Datos
{
    public static class RepositorioCaballos
    {
        private static List<Caballo> listaCaballos = new List<Caballo>();

        // Ruta del JSON (queda dentro del output: bin/Debug/.../Datos/caballos.json)
        private static string RutaJson =>
            Path.Combine(AppContext.BaseDirectory, "Datos", "caballos.json");

        // Llamar 1 vez al iniciar el módulo / programa
        public static void CargarDesdeJson()
        {
            try
            {
                // Asegurar carpeta Datos en output
                string carpeta = Path.GetDirectoryName(RutaJson)!;
                if (!Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                // Si no existe el archivo, lo crea con una lista vacía (o con ejemplos)
                if (!File.Exists(RutaJson))
                {
                    listaCaballos = new List<Caballo>();
                    GuardarEnJson(); // crea el archivo
                    return;
                }

                string json = File.ReadAllText(RutaJson);

                // Si está vacío o mal, evita crash
                if (string.IsNullOrWhiteSpace(json))
                {
                    listaCaballos = new List<Caballo>();
                    return;
                }

                var datos = JsonSerializer.Deserialize<List<Caballo>>(json);
                listaCaballos = datos ?? new List<Caballo>();
            }
            catch
            {
                // Si algo falla, por seguridad no revienta el programa
                listaCaballos = new List<Caballo>();
            }
        }

        private static void GuardarEnJson()
        {
            try
            {
                var opciones = new JsonSerializerOptions
                {
                    WriteIndented = true
                };

                string json = JsonSerializer.Serialize(listaCaballos, opciones);
                File.WriteAllText(RutaJson, json);
            }
            catch
            {
                // Si no puede guardar (permisos), no revienta
            }
        }

        public static List<Caballo> ObtenerTodos()
        {
            return listaCaballos;
        }

        public static bool Agregar(Caballo caballo)
        {
            if (caballo == null) return false;

            // Validar edad
            if (caballo.Edad < 0 || caballo.Edad > 30)
                return false;

            string nombreNuevo = (caballo.Nombre ?? "").Trim();

            // Validar nombre vacío
            if (string.IsNullOrWhiteSpace(nombreNuevo))
                return false;

            // Validar nombre repetido (ignorando mayúsculas)
            bool repetido = listaCaballos.Any(c =>
                string.Equals((c.Nombre ?? "").Trim(), nombreNuevo, StringComparison.OrdinalIgnoreCase));

            if (repetido)
                return false;

            caballo.Nombre = nombreNuevo;

            listaCaballos.Add(caballo);
            GuardarEnJson(); // ✅ persistencia
            return true;
        }

        public static bool Editar(string nombre, int nuevaEdad, string nuevaRaza)
        {
            if (nuevaEdad < 0 || nuevaEdad > 30)
                return false;

            string buscado = (nombre ?? "").Trim();
            if (string.IsNullOrWhiteSpace(buscado))
                return false;

            for (int i = 0; i < listaCaballos.Count; i++)
            {
                if (string.Equals((listaCaballos[i].Nombre ?? "").Trim(), buscado, StringComparison.OrdinalIgnoreCase))
                {
                    listaCaballos[i].Edad = nuevaEdad;
                    listaCaballos[i].Raza = nuevaRaza ?? "";
                    GuardarEnJson(); // ✅ persistencia
                    return true;
                }
            }

            return false;
        }

        // (Opcional) por si quieres borrar después
        public static bool Eliminar(string nombre)
        {
            string buscado = (nombre ?? "").Trim();
            var caballo = listaCaballos.FirstOrDefault(c =>
                string.Equals((c.Nombre ?? "").Trim(), buscado, StringComparison.OrdinalIgnoreCase));

            if (caballo == null) return false;

            listaCaballos.Remove(caballo);
            GuardarEnJson();
            return true;
        }
    }
}
