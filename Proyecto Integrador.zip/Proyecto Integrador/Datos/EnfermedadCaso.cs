﻿namespace Proyecto_Integrador.Datos
{
    public class EnfermedadCaso
    {
        public int EnfermedadId { get; set; }
        public DateTime Fecha { get; set; } = DateTime.Now;
        public string Notas { get; set; } = "";
        public bool Activa { get; set; } = true;
    }
}
