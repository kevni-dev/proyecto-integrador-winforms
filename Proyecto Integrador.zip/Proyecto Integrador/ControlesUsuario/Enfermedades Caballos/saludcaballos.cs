﻿using System;
using System.Windows.Forms;

namespace Proyecto_Integrador.ControlesUsuario.Enfermedades_Caballos
{
    public partial class Saludcaballos : UserControl
    {
        public Saludcaballos()
        {
            InitializeComponent();

            // Si en el diseñador ya está conectado, no pasa nada.
            // Esto asegura que el click funcione aunque no esté enganchado en Designer.
            btn_minijuego.Click += btn_minijuego_Click;
        }

        private void saludcaballos_Load(object sender, EventArgs e)
        {
            // Al entrar al módulo, mostramos la vista principal
            VolverInicio();
        }

        // ✅ Carga cualquier vista en panel3 (y mata la anterior)
        private void CargarVista(Control vista)
        {
            foreach (Control c in panel3.Controls)
                c.Dispose();

            panel3.Controls.Clear();

            vista.Dock = DockStyle.Fill;
            panel3.Controls.Add(vista);
        }

        // ✅ Vuelve a la tabla principal (o lo que quieras mostrar por defecto)
        private void VolverInicio()
        {
            foreach (Control c in panel3.Controls)
                c.Dispose();

            panel3.Controls.Clear();

            dtgv_caballos.Dock = DockStyle.Fill;
            panel3.Controls.Add(dtgv_caballos);
        }

        // ✅ Antes abría ventana: ahora carga el UserControl
        private void btn_enferme_Click(object sender, EventArgs e)
        {
            var v = new cuEnfermedades();
            v.SalirRequested += (s, a) => VolverInicio();
            CargarVista(v);
        }

        // ✅ Antes abría ventana: ahora carga el UserControl
        private void btn_tratamiento_Click(object sender, EventArgs e)
        {
            var v = new cuTratamientos();
            v.SalirRequested += (s, a) => VolverInicio();
            CargarVista(v);
        }

        // ✅ Minijuego dentro del panel y con salida limpia
        private void btn_minijuego_Click(object? sender, EventArgs e)
        {
            var juego = new cuSopaEnfermedades();
            juego.SalirRequested += (s, args) => VolverInicio();
            CargarVista(juego);
        }
    }
}
