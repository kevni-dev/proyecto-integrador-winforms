﻿using Proyecto_Integrador.Archivo;
using System;
using System.IO;
using System.Windows.Forms;

namespace Proyecto_Integrador.ControlesUsuario.Enfermedades_Caballos
{
    public partial class cuTratamientos : UserControl
    {
        public event EventHandler? SalirRequested;

        private Archivo.Archivo archivo;
        private string ruta;
        private string rutaEnfermedades;

        private string[] enfermedades = Array.Empty<string>();

        public cuTratamientos()
        {
            InitializeComponent();

            archivo = new Archivo.Archivo();
            ruta = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"Datos\Tratamientos.txt");
            rutaEnfermedades = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"Datos\Enfermedades.txt");

            this.Load += cuTratamientos_Load;

            btn_guardar.Click += btn_guardar_Click;
            btn_eliminar.Click += btn_eliminar_Click;
            dtgv_tratamiento.CellClick += dtgv_tratamiento_CellClick;

            
        }

       

        private void cuTratamientos_Load(object? sender, EventArgs e)
        {
            enfermedades = obtenerEnfermedades();
            if (enfermedades == null || enfermedades.Length == 0) return;

            cargarEnfermedadesComboBox(enfermedades);
            cargarTabla(enfermedades);
        }

        private string[] obtenerEnfermedades()
        {
            return archivo.leerArchivo(rutaEnfermedades);
        }

        private void cargarEnfermedadesComboBox(string[] enfermedadesS)
        {
            string[] enfermedadesFormateadas = new string[enfermedadesS.Length];

            for (int i = 0; i < enfermedadesS.Length; i++)
            {
                string[] linea = enfermedadesS[i].Split(';');
                // id:nombre
                enfermedadesFormateadas[i] = linea[0] + ":" + linea[1];
            }

            cmb_enfermedades.DataSource = enfermedadesFormateadas;
        }

        private void cargarTabla(string[] enfermedadesLocal)
        {
            dtgv_tratamiento.Rows.Clear();
            string[] datos = archivo.leerArchivo(ruta);
            if (datos == null) return;

            for (int i = 0; i < datos.Length; i++)
            {
                dtgv_tratamiento.Rows.Add();
                string[] tratamiento = datos[i].Split(';');

                string nombreEnfermedad = "";
                for (int j = 0; j < enfermedadesLocal.Length; j++)
                {
                    string[] enfermedad = enfermedadesLocal[j].Split(";");
                    if (enfermedad[0] == tratamiento[1])
                    {
                        nombreEnfermedad = enfermedad[1];
                        break;
                    }
                }

                dtgv_tratamiento.Rows[i].Cells[0].Value = tratamiento[0];
                dtgv_tratamiento.Rows[i].Cells[1].Value = tratamiento[1];
                dtgv_tratamiento.Rows[i].Cells[2].Value = nombreEnfermedad;
                dtgv_tratamiento.Rows[i].Cells[3].Value = tratamiento[2];
            }
        }

        private int obtenerIdMax()
        {
            string[] datos = archivo.leerArchivo(ruta);
            int max = 0;
            if (datos == null) return 0;

            for (int i = 0; i < datos.Length; i++)
            {
                string[] linea = datos[i].Split(';');
                int id = int.Parse(linea[0]);
                if (id > max) max = id;
            }
            return max;
        }

        private void btn_guardar_Click(object? sender, EventArgs e)
        {
            if (txt_tratamiento.Text.Length <= 0)
            {
                MessageBox.Show("Rellene el tratamiento");
                return;
            }
            if (txt_tratamiento.Text.Length >= 30)
            {
                MessageBox.Show("La longuitud del tratamiento debe ser menos a 30 caracteres");
                return;
            }

            bool editar = txt_id.Text.Length > 0;
            string enfId = cmb_enfermedades.Text.Split(':')[0];

            if (editar)
            {
                string datos = txt_id.Text + ";" + enfId + ";" + txt_tratamiento.Text;
                archivo.editarLinea(int.Parse(txt_id.Text), datos, ruta);
            }
            else
            {
                int max = obtenerIdMax() + 1;
                string datos = max + ";" + enfId + ";" + txt_tratamiento.Text + "\n";
                archivo.escribirLinea(ruta, datos);
            }

            cargarTabla(enfermedades);
            txt_id.Text = "";
            txt_tratamiento.Text = "";
        }

        private void btn_eliminar_Click(object? sender, EventArgs e)
        {
            if (txt_id.Text.Length == 0) return;

            int id = int.Parse(txt_id.Text);
            archivo.eliminarLinea(id, ruta);
            cargarTabla(enfermedades);

            txt_id.Text = "";
            txt_tratamiento.Text = "";
        }

        private void dtgv_tratamiento_CellClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) return;

            string id = dtgv_tratamiento.Rows[e.RowIndex].Cells[0].Value?.ToString() ?? "";
            string tratamiento = dtgv_tratamiento.Rows[e.RowIndex].Cells[3].Value?.ToString() ?? "";

            txt_tratamiento.Text = tratamiento;
            txt_id.Text = id;
        }
    }
}
