﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Proyecto_Integrador.Datos;

namespace Proyecto_Integrador.ControlesUsuario.A_Turismo
{
    public partial class TurismoVerRegistro : UserControl
    {
        private List<Caballo> listaCaballos = new List<Caballo>();
        private BindingSource fuenteCaballos = new BindingSource();

        private bool _recargando = false;

        public TurismoVerRegistro()
        {
            InitializeComponent();

            Load += TurismoVerRegistro_Load;

            txtBuscar.TextChanged += (_, __) => AplicarBusquedaPorNombre();

            // MUY IMPORTANTE: usar un handler "normal" para poder quitarlo al recargar
            dataGridCaballos.SelectionChanged += DataGridCaballos_SelectionChanged;
        }

        private void TurismoVerRegistro_Load(object? sender, EventArgs e)
        {
            ConfigurarTabla();
            CargarCaballos(reseleccionar: false);
            MostrarVistaPreviaActual();
        }

        private void ConfigurarTabla()
        {
            dataGridCaballos.AutoGenerateColumns = true;
            dataGridCaballos.ReadOnly = true;
            dataGridCaballos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridCaballos.MultiSelect = false;

            dataGridCaballos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridCaballos.RowHeadersVisible = false;

            // Esto evita comportamientos raros de selección
            dataGridCaballos.ClearSelection();

            dataGridCaballos.DataSource = fuenteCaballos;
        }

        private void DataGridCaballos_SelectionChanged(object? sender, EventArgs e)
        {
            if (_recargando) return;
            MostrarVistaPreviaActual();
        }

        private void CargarCaballos(bool reseleccionar)
        {
            _recargando = true;
            try
            {
                // Evita que SelectionChanged corra mientras cambias DataSource
                dataGridCaballos.SelectionChanged -= DataGridCaballos_SelectionChanged;

                var datos = RepositorioCaballos.ObtenerTodos();
                listaCaballos = datos ?? new List<Caballo>();

                // Reset seguro
                fuenteCaballos.DataSource = null;
                fuenteCaballos.DataSource = listaCaballos;

                // limpia selección
                dataGridCaballos.ClearSelection();

                // si quieres seleccionar algo automáticamente (opcional)
                if (reseleccionar && dataGridCaballos.Rows.Count > 0)
                {
                    dataGridCaballos.Rows[0].Selected = true;
                }
            }
            finally
            {
                dataGridCaballos.SelectionChanged += DataGridCaballos_SelectionChanged;
                _recargando = false;
            }
        }

        private void AplicarBusquedaPorNombre()
        {
            _recargando = true;
            try
            {
                dataGridCaballos.SelectionChanged -= DataGridCaballos_SelectionChanged;

                string texto = txtBuscar.Text.Trim();
                if (string.IsNullOrEmpty(texto))
                {
                    fuenteCaballos.DataSource = null;
                    fuenteCaballos.DataSource = listaCaballos;
                }
                else
                {
                    string lower = texto.ToLower();
                    var filtrado = listaCaballos
                        .Where(c => (c.Nombre ?? "").ToLower().Contains(lower))
                        .ToList();

                    fuenteCaballos.DataSource = null;
                    fuenteCaballos.DataSource = filtrado;
                }

                dataGridCaballos.ClearSelection();
                pictureCaballo.Image = null;

                // Selecciona la primera fila del resultado si existe
                if (dataGridCaballos.Rows.Count > 0)
                    dataGridCaballos.Rows[0].Selected = true;
            }
            finally
            {
                dataGridCaballos.SelectionChanged += DataGridCaballos_SelectionChanged;
                _recargando = false;
            }

            MostrarVistaPreviaActual();
        }

        private Caballo? CaballoSeleccionado()
        {
            if (_recargando) return null;

            if (dataGridCaballos.SelectedRows.Count == 0)
                return null;

            var row = dataGridCaballos.SelectedRows[0];
            if (row == null || row.IsNewRow)
                return null;

            return row.DataBoundItem as Caballo;
        }

        private void MostrarVistaPreviaActual()
        {
            if (_recargando) return;

            var item = CaballoSeleccionado();
            if (item == null)
            {
                pictureCaballo.Image = null;
                return;
            }

            string clave = item.ImagenRecurso ?? "";

            if (clave == "Caballo_Cuarto")
                pictureCaballo.Image = Properties.Resources.Caballo_Cuarto;
            else if (clave == "Caballo_Arabe")
                pictureCaballo.Image = Properties.Resources.Caballo_Arabe;
            else if (clave == "Caballo_Criollo")
                pictureCaballo.Image = Properties.Resources.Caballo_Criollo;
            else
                pictureCaballo.Image = null;
        }

        // =========================
        //   BOTÓN ELIMINAR
        // =========================
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            var item = CaballoSeleccionado();
            if (item == null)
            {
                MessageBox.Show("Selecciona un caballo primero.");
                return;
            }

            var ok = MessageBox.Show(
                $"¿Eliminar a \"{item.Nombre}\"?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (ok != DialogResult.Yes) return;

            _recargando = true;
            try
            {
                bool eliminado = RepositorioCaballos.Eliminar(item.Nombre);

                if (!eliminado)
                {
                    MessageBox.Show("No se pudo eliminar.");
                    return;
                }

                // Recarga lista real desde repo y aplica filtro otra vez
                CargarCaballos(reseleccionar: true);
                AplicarBusquedaPorNombre();
            }
            finally
            {
                _recargando = false;
            }

            MostrarVistaPreviaActual();
        }

        // =========================
        //   BOTÓN EDITAR
        // =========================
        private void btnEditar_Click(object sender, EventArgs e)
        {
            var item = CaballoSeleccionado();
            if (item == null)
            {
                MessageBox.Show("Selecciona un caballo primero.");
                return;
            }

            string nombreOriginal = item.Nombre ?? "";

            using (var f = new FormEditarCaballo(item))
            {
                if (f.ShowDialog() != DialogResult.OK)
                    return;

                Caballo actualizado = f.CaballoActualizado;

                bool ok = RepositorioCaballos.Actualizar(nombreOriginal, actualizado);

                if (!ok)
                {
                    MessageBox.Show("No se pudo editar (edad inválida o nombre repetido).");
                    return;
                }
            }

            // recargar lista
            CargarCaballos(reseleccionar: true);
            AplicarBusquedaPorNombre();
            MostrarVistaPreviaActual();
        }

        private void pictureCaballo_Click(object sender, EventArgs e)
        {
            // Si no quieres click, quita el evento del designer.
        }
    }

    // ==========================================
    //   FORM SIMPLE PARA EDITAR CABALLO
    // ==========================================
    internal class FormEditarCaballo : Form
    {
        public Caballo CaballoActualizado { get; private set; }

        private TextBox txtNombre = new TextBox();
        private TextBox txtEdad = new TextBox();
        private ComboBox cbRaza = new ComboBox();
        private ComboBox cbSexo = new ComboBox();
        private ComboBox cbTemperamento = new ComboBox();
        private ComboBox cbImagen = new ComboBox();
        private Button btnOk = new Button();
        private Button btnCancel = new Button();

        public FormEditarCaballo(Caballo original)
        {
            Text = "Editar Caballo";
            Width = 420;
            Height = 360;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;

            Label L(string t, int y)
            {
                var l = new Label { Text = t, Left = 20, Top = y, Width = 120 };
                Controls.Add(l);
                return l;
            }

            void Place(Control c, int y)
            {
                c.Left = 150;
                c.Top = y;
                c.Width = 220;
                Controls.Add(c);
            }

            L("Nombre:", 20); Place(txtNombre, 18);
            L("Edad:", 60); Place(txtEdad, 58);
            L("Raza:", 100); Place(cbRaza, 98);
            L("Sexo:", 140); Place(cbSexo, 138);
            L("Temperamento:", 180); Place(cbTemperamento, 178);
            L("Imagen:", 220); Place(cbImagen, 218);

            cbRaza.DropDownStyle = ComboBoxStyle.DropDownList;
            cbSexo.DropDownStyle = ComboBoxStyle.DropDownList;
            cbTemperamento.DropDownStyle = ComboBoxStyle.DropDownList;
            cbImagen.DropDownStyle = ComboBoxStyle.DropDownList;

            cbRaza.Items.AddRange(new object[] { "Árabe", "Criollo", "Cuarto de milla" });
            cbSexo.Items.AddRange(new object[] { "Macho", "Hembra" });
            cbTemperamento.Items.AddRange(new object[] { "Tranquilo", "Nervioso", "Agresivo", "Activo" });
            cbImagen.Items.AddRange(new object[] { "Caballo_Arabe", "Caballo_Criollo", "Caballo_Cuarto" });

            txtNombre.Text = original.Nombre ?? "";
            txtEdad.Text = original.Edad.ToString();
            cbRaza.SelectedItem = original.Raza;
            cbSexo.SelectedItem = original.Sexo;
            cbTemperamento.SelectedItem = original.Temperamento;
            cbImagen.SelectedItem = original.ImagenRecurso;

            if (cbRaza.SelectedIndex < 0) cbRaza.SelectedIndex = 0;
            if (cbSexo.SelectedIndex < 0) cbSexo.SelectedIndex = 0;
            if (cbTemperamento.SelectedIndex < 0) cbTemperamento.SelectedIndex = 0;
            if (cbImagen.SelectedIndex < 0) cbImagen.SelectedIndex = 0;

            btnOk.Text = "Guardar";
            btnOk.Left = 150;
            btnOk.Top = 260;
            btnOk.Width = 100;
            btnOk.Click += (_, __) => Guardar();

            btnCancel.Text = "Cancelar";
            btnCancel.Left = 270;
            btnCancel.Top = 260;
            btnCancel.Width = 100;
            btnCancel.Click += (_, __) => { DialogResult = DialogResult.Cancel; Close(); };

            Controls.Add(btnOk);
            Controls.Add(btnCancel);

            CaballoActualizado = new Caballo();
        }

        private void Guardar()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text.Trim()))
            {
                MessageBox.Show("Nombre vacío");
                return;
            }

            if (!int.TryParse(txtEdad.Text.Trim(), out int edad))
            {
                MessageBox.Show("Edad inválida");
                return;
            }

            CaballoActualizado = new Caballo
            {
                Nombre = txtNombre.Text.Trim(),
                Edad = edad,
                Raza = cbRaza.Text,
                Sexo = cbSexo.Text,
                Temperamento = cbTemperamento.Text,
                ImagenRecurso = cbImagen.Text
            };

            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
