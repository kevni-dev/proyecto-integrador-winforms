﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Proyecto_Integrador.ControlesUsuario
{
    public partial class TurismoMinijuego : UserControl
    {
        public event EventHandler? CancelarPresionado;

        private PictureBox? imagenSeleccionada = null;

        private Point[] posiciones = Array.Empty<Point>();
        private Size[] tamanios = Array.Empty<Size>();

        private readonly Random rnd = new Random();
        private bool _inicializado = false;

        public TurismoMinijuego()
        {
            InitializeComponent();
            InicializarJuego();

            this.Resize += (s, e) => AjustarLayout();
            this.Load += (s, e) =>
            {
                if (_inicializado) return;
                _inicializado = true;

                GuardarPosiciones();
                MezclarImagenes();
                AjustarLayout();
            };
        }

        private void InicializarJuego()
        {
            pictureBox1.Click += Imagen_Click;
            pictureBox2.Click += Imagen_Click;
            pictureBox3.Click += Imagen_Click;
            pictureBox4.Click += Imagen_Click;

            panel2.Click += Panel_Click;
            panel3.Click += Panel_Click;
            panel4.Click += Panel_Click;
            panel5.Click += Panel_Click;

            btnGuardar.Click += btnGuardar_Click;
            btnCancelar.Click += btnCancelar_Click;
            btnSalir.Click += btnSalir_Click;
        }

        // Ajusta y centra bonito sin romper el juego
        private void AjustarLayout()
        {
            int margen = 40;

            // Botones arriba derecha
            int yBotones = 20;
            btnGuardar.Top = yBotones;
            btnCancelar.Top = yBotones;
            btnSalir.Top = yBotones;

            btnGuardar.Left = this.ClientSize.Width - margen - btnGuardar.Width;
            btnCancelar.Left = btnGuardar.Left - 10 - btnCancelar.Width;
            btnSalir.Left = btnCancelar.Left - 10 - btnSalir.Width;

            // Texto de orden
            label2.Left = margen;
            label2.Top = yBotones + btnGuardar.Height + 15;

            // ANCHO DINÁMICO (CLAVE)
            int anchoUtil = this.ClientSize.Width - (margen * 2);
            int anchoMax = Math.Min(anchoUtil, 1100); // límite visual bonito

            panelLineaTiempo.Width = anchoMax;
            panel1.Width = anchoMax;

            // Centrar horizontalmente
            panelLineaTiempo.Left = (this.ClientSize.Width - panelLineaTiempo.Width) / 2;
            panel1.Left = (this.ClientSize.Width - panel1.Width) / 2;

            // Posiciones verticales
            panelLineaTiempo.Top = label2.Bottom + 25;
            panel1.Top = panelLineaTiempo.Bottom + 35;
        }


        private void GuardarPosiciones()
        {
            posiciones = new Point[4];
            tamanios = new Size[4];

            posiciones[0] = pictureBox1.Location;
            posiciones[1] = pictureBox2.Location;
            posiciones[2] = pictureBox3.Location;
            posiciones[3] = pictureBox4.Location;

            tamanios[0] = pictureBox1.Size;
            tamanios[1] = pictureBox2.Size;
            tamanios[2] = pictureBox3.Size;
            tamanios[3] = pictureBox4.Size;
        }

        private void Imagen_Click(object? sender, EventArgs e)
        {
            if (sender is not PictureBox pb) return;

            if (imagenSeleccionada != null)
                imagenSeleccionada.BorderStyle = BorderStyle.None;

            imagenSeleccionada = pb;
            imagenSeleccionada.BorderStyle = BorderStyle.FixedSingle;
        }

        // Swap si el destino ya tiene una imagen
        private void Panel_Click(object? sender, EventArgs e)
        {
            if (imagenSeleccionada == null) return;
            if (sender is not Panel destino) return;

            Control parentOrigen = imagenSeleccionada.Parent;

            PictureBox? pbDestino = null;
            if (destino.Controls.Count > 0)
                pbDestino = destino.Controls[0] as PictureBox;

            if (pbDestino != null)
            {
                pbDestino.Parent = parentOrigen;
                pbDestino.Location = imagenSeleccionada.Location;
                pbDestino.Size = imagenSeleccionada.Size;
            }

            imagenSeleccionada.Parent = destino;
            imagenSeleccionada.Location = new Point(0, 0);
            imagenSeleccionada.Size = destino.Size;

            imagenSeleccionada.BorderStyle = BorderStyle.None;
            imagenSeleccionada = null;
        }

        private void btnGuardar_Click(object? sender, EventArgs e)
        {
            bool correcto =
                panel2.Controls.Contains(pictureBox1) &&
                panel3.Controls.Contains(pictureBox2) &&
                panel4.Controls.Contains(pictureBox3) &&
                panel5.Controls.Contains(pictureBox4);

            MessageBox.Show(correcto ? "¡Orden correcto!" : "Orden incorrecto. Intenta otra vez.");
        }

        private void btnCancelar_Click(object? sender, EventArgs e)
        {
            ReiniciarJuego();
        }

        private void ReiniciarJuego()
        {
            pictureBox1.Parent = panel1;
            pictureBox2.Parent = panel1;
            pictureBox3.Parent = panel1;
            pictureBox4.Parent = panel1;

            pictureBox1.Location = posiciones[0];
            pictureBox2.Location = posiciones[1];
            pictureBox3.Location = posiciones[2];
            pictureBox4.Location = posiciones[3];

            pictureBox1.Size = tamanios[0];
            pictureBox2.Size = tamanios[1];
            pictureBox3.Size = tamanios[2];
            pictureBox4.Size = tamanios[3];

            imagenSeleccionada = null;
            MezclarImagenes();
        }

        private void MezclarImagenes()
        {
            Point[] copia = (Point[])posiciones.Clone();

            for (int i = copia.Length - 1; i > 0; i--)
            {
                int j = rnd.Next(i + 1);
                (copia[i], copia[j]) = (copia[j], copia[i]);
            }

            pictureBox1.Location = copia[0];
            pictureBox2.Location = copia[1];
            pictureBox3.Location = copia[2];
            pictureBox4.Location = copia[3];
        }

        private void btnSalir_Click(object? sender, EventArgs e)
        {
            CancelarPresionado?.Invoke(this, EventArgs.Empty);
        }
    }
}
