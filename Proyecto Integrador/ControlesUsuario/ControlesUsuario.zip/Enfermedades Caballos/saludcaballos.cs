﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Proyecto_Integrador.Datos;

namespace Proyecto_Integrador.ControlesUsuario.Enfermedades_Caballos
{
    public partial class Saludcaballos : UserControl
    {
        private List<Caballo> _caballos = new();

        public Saludcaballos()
        {
            InitializeComponent();

            // por si no está enganchado en el Designer
            btn_minijuego.Click += btn_minijuego_Click;
        }

        private void saludcaballos_Load(object sender, EventArgs e)
        {
            // Cargar del JSON
            RepositorioCaballos.CargarDesdeJson();

            // Pintar tabla
            CargarTablaCaballos();

            // Vista principal
            VolverInicio();
        }

        private void CargarTablaCaballos()
        {
            _caballos = RepositorioCaballos.ObtenerTodos();

            dtgv_caballos.AutoGenerateColumns = true;
            dtgv_caballos.DataSource = null;
            dtgv_caballos.DataSource = _caballos; // ✅ ahora sí son objetos Caballo reales

            dtgv_caballos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtgv_caballos.MultiSelect = false;
            dtgv_caballos.ReadOnly = true;
            dtgv_caballos.RowHeadersVisible = false;
            dtgv_caballos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Ocultar columnas que no quieres mostrar
            if (dtgv_caballos.Columns["Enfermedades"] != null)
                dtgv_caballos.Columns["Enfermedades"].Visible = false;

            if (dtgv_caballos.Columns["ImagenRecurso"] != null)
                dtgv_caballos.Columns["ImagenRecurso"].Visible = false;
        }

        private void CargarVista(Control vista)
        {
            foreach (Control c in panel3.Controls)
                c.Dispose();

            panel3.Controls.Clear();

            vista.Dock = DockStyle.Fill;
            panel3.Controls.Add(vista);
        }

        private void VolverInicio()
        {
            foreach (Control c in panel3.Controls)
                c.Dispose();

            panel3.Controls.Clear();

            // refrescar por si hubo cambios
            CargarTablaCaballos();

            dtgv_caballos.Dock = DockStyle.Fill;
            panel3.Controls.Add(dtgv_caballos);
        }

        private Caballo? ObtenerCaballoSeleccionado()
        {
            if (dtgv_caballos.CurrentRow == null) return null;
            return dtgv_caballos.CurrentRow.DataBoundItem as Caballo;
        }

        // ✅ AHORA "ENFERMEDADES" = enfermedades del caballo seleccionado
        private void btn_enferme_Click(object sender, EventArgs e)
        {
            var caballo = ObtenerCaballoSeleccionado();
            if (caballo == null)
            {
                MessageBox.Show("Selecciona un caballo primero (clic en una fila).");
                return;
            }

            var v = new cuEnfermedadesPorCaballo(caballo);
            v.SalirRequested += (s, a) => VolverInicio();
            CargarVista(v);
        }

        private void btn_tratamiento_Click(object sender, EventArgs e)
        {
            var v = new cuTratamientos();
            // si tu cuTratamientos tiene SalirRequested, conecta:
            // v.SalirRequested += (s, a) => VolverInicio();
            CargarVista(v);
        }

        private void btn_minijuego_Click(object? sender, EventArgs e)
        {
            var juego = new cuSopaEnfermedades();
            juego.SalirRequested += (s, args) => VolverInicio();
            CargarVista(juego);
        }
    }
}
