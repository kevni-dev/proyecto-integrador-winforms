﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace Proyecto_Integrador.Datos
{
    public static class RepositorioCaballos
    {
        private static List<Caballo> listaCaballos = new List<Caballo>();

        // Ruta del JSON (queda dentro del output: bin/Debug/.../Datos/caballos.json)
        private static string RutaJson =>
            Path.Combine(AppContext.BaseDirectory, "Datos", "caballos.json");

        // Llamar 1 vez al iniciar el módulo / programa
        public static void CargarDesdeJson()
        {
            try
            {
                // Asegurar carpeta Datos en output
                string? carpeta = Path.GetDirectoryName(RutaJson);
                if (!string.IsNullOrWhiteSpace(carpeta) && !Directory.Exists(carpeta))
                    Directory.CreateDirectory(carpeta);

                // Si no existe el archivo, lo crea con una lista vacía
                if (!File.Exists(RutaJson))
                {
                    listaCaballos = new List<Caballo>();
                    GuardarEnJson();
                    return;
                }

                string json = File.ReadAllText(RutaJson);

                // Si está vacío, lista vacía
                if (string.IsNullOrWhiteSpace(json))
                {
                    listaCaballos = new List<Caballo>();
                    return;
                }

                var datos = JsonSerializer.Deserialize<List<Caballo>>(json);
                listaCaballos = datos ?? new List<Caballo>();
            }
            catch
            {
                // Si algo falla, por seguridad no revienta el programa
                listaCaballos = new List<Caballo>();
            }
        }

        private static void GuardarEnJson()
        {
            try
            {
                var opciones = new JsonSerializerOptions
                {
                    WriteIndented = true
                };

                string json = JsonSerializer.Serialize(listaCaballos, opciones);
                File.WriteAllText(RutaJson, json);
            }
            catch
            {
                // Si no puede guardar, no revienta
            }
        }

        public static List<Caballo> ObtenerTodos()
        {
            return listaCaballos;
        }

        public static bool Agregar(Caballo caballo)
        {
            if (caballo == null) return false;

            // Validar edad
            if (caballo.Edad < 0 || caballo.Edad > 30)
                return false;

            string nombreNuevo = (caballo.Nombre ?? "").Trim();

            // Validar nombre vacío
            if (string.IsNullOrWhiteSpace(nombreNuevo))
                return false;

            // Validar nombre repetido (ignorando mayúsculas)
            bool repetido = listaCaballos.Any(c =>
                string.Equals((c.Nombre ?? "").Trim(), nombreNuevo, StringComparison.OrdinalIgnoreCase));

            if (repetido)
                return false;

            caballo.Nombre = nombreNuevo;

            listaCaballos.Add(caballo);
            GuardarEnJson();
            return true;
        }

        // ✅ EDITAR COMPLETO (lo que usarás para el botón Editar)
        public static bool Actualizar(string nombreOriginal, Caballo actualizado)
        {
            if (actualizado == null) return false;

            string original = (nombreOriginal ?? "").Trim();
            if (string.IsNullOrWhiteSpace(original)) return false;

            // Buscar caballo
            Caballo? existente = listaCaballos.FirstOrDefault(c =>
                string.Equals((c.Nombre ?? "").Trim(), original, StringComparison.OrdinalIgnoreCase));

            if (existente == null) return false;

            // Validaciones
            string nuevoNombre = (actualizado.Nombre ?? "").Trim();
            if (string.IsNullOrWhiteSpace(nuevoNombre)) return false;

            if (actualizado.Edad < 0 || actualizado.Edad > 30) return false;

            // Si cambió el nombre, que no se repita
            bool repetido = listaCaballos.Any(c =>
                !ReferenceEquals(c, existente) &&
                string.Equals((c.Nombre ?? "").Trim(), nuevoNombre, StringComparison.OrdinalIgnoreCase));

            if (repetido) return false;

            // Actualizar campos
            existente.Nombre = nuevoNombre;
            existente.Edad = actualizado.Edad;
            existente.Raza = actualizado.Raza ?? "";
            existente.Sexo = actualizado.Sexo ?? "";
            existente.Temperamento = actualizado.Temperamento ?? "";
            existente.ImagenRecurso = actualizado.ImagenRecurso ?? "";

            GuardarEnJson();
            return true;
        }

        // (Opcional) si quieres mantener este método viejo, sirve,
        // pero ya no lo necesitas si usas Actualizar(...)
        public static bool Editar(string nombre, int nuevaEdad, string nuevaRaza)
        {
            if (nuevaEdad < 0 || nuevaEdad > 30)
                return false;

            string buscado = (nombre ?? "").Trim();
            if (string.IsNullOrWhiteSpace(buscado))
                return false;

            for (int i = 0; i < listaCaballos.Count; i++)
            {
                if (string.Equals((listaCaballos[i].Nombre ?? "").Trim(), buscado, StringComparison.OrdinalIgnoreCase))
                {
                    listaCaballos[i].Edad = nuevaEdad;
                    listaCaballos[i].Raza = nuevaRaza ?? "";
                    GuardarEnJson();
                    return true;
                }
            }

            return false;
        }

        public static bool Eliminar(string nombre)
        {
            string buscado = (nombre ?? "").Trim();

            var caballo = listaCaballos.FirstOrDefault(c =>
                string.Equals((c.Nombre ?? "").Trim(), buscado, StringComparison.OrdinalIgnoreCase));

            if (caballo == null) return false;

            listaCaballos.Remove(caballo);
            GuardarEnJson();
            return true;
        }
    }
}
